- 👋 Hi, I’m @nnknishant
- 👀 I’m interested in new learning in technical skills.
- 🌱 I’m currently learning Power Bi tools, SQL, Python from last six months and other languages also.
- 💞️ I’m looking to collaborate getting best organisation and want to grow my skill and knowledge.
- 📫 How to reach me ...Please reach out to me on linked in profile.
- https://www.linkedin.com/in/nishant-nandkeolyar-6089a2206

<!---
nnknishant/nnknishant is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
